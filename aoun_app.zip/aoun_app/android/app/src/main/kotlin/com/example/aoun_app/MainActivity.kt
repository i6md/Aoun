package com.example.aoun_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
